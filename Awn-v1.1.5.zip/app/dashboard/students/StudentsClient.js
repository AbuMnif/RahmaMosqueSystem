"use client";

import { useCallback, useEffect, useMemo, useState } from "react";

const MAX_ATTEMPTS = 3;

function wait(milliseconds) {
  return new Promise((resolve) => setTimeout(resolve, milliseconds));
}

async function fetchWithRetry(url, options = {}) {
  let lastError;

  for (let attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {
    try {
      const response = await fetch(url, {
        ...options,
        cache: "no-store",
      });

      let result;

      try {
        result = await response.json();
      } catch {
        throw new Error("استجابة الخادم غير صالحة.");
      }

      if (response.ok) {
        return result;
      }

      const error = new Error(
        result?.error || `حدث خطأ في الطلب (${response.status}).`
      );

      error.status = response.status;

      if (
        response.status >= 400 &&
        response.status < 500 &&
        response.status !== 408 &&
        response.status !== 429
      ) {
        throw error;
      }

      lastError = error;
    } catch (error) {
      lastError = error;

      if (
        error.status >= 400 &&
        error.status < 500 &&
        error.status !== 408 &&
        error.status !== 429
      ) {
        throw error;
      }
    }

    if (attempt < MAX_ATTEMPTS) {
      await wait(attempt * 1000);
    }
  }

  throw lastError || new Error("تعذر الاتصال بالخادم بعد عدة محاولات.");
}

export default function StudentsClient({ profile }) {
  const isPlatformSupervisor =
    profile?.role === "platform_supervisor";

  const [students, setStudents] = useState([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const loadStudents = useCallback(async () => {
    setLoading(true);
    setError("");

    try {
      const result = await fetchWithRetry("/api/students", {
        method: "GET",
      });

      setStudents(Array.isArray(result.students) ? result.students : []);
    } catch (err) {
      setError(
        err.message || "تعذر تحميل بيانات الطلاب بعد ثلاث محاولات."
      );
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadStudents();
  }, [loadStudents]);

  const filteredStudents = useMemo(() => {
    const query = search.trim().toLowerCase();

    if (!query) return students;

    return students.filter((student) => {
      const fullName = [
        student.first_name,
        student.middle_name,
        student.last_name,
      ]
        .filter(Boolean)
        .join(" ")
        .toLowerCase();

      const guardianName =
        student.guardian?.full_name?.toLowerCase() || "";

      const guardianUsername =
        student.guardian?.username?.toLowerCase() || "";

      return (
        fullName.includes(query) ||
        guardianName.includes(query) ||
        guardianUsername.includes(query)
      );
    });
  }, [students, search]);

  function getStudentName(student) {
    return [
      student.first_name,
      student.middle_name,
      student.last_name,
    ]
      .filter(Boolean)
      .join(" ");
  }

  function getCurrentClass(student) {
    return student.current_enrollment?.class?.name || "غير مسجل في حلقة";
  }

  function formatDate(date) {
    if (!date) return "غير محدد";

    const parsedDate = new Date(`${date}T00:00:00`);

    if (Number.isNaN(parsedDate.getTime())) {
      return "غير محدد";
    }

    return new Intl.DateTimeFormat("ar", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
    }).format(parsedDate);
  }

  const roleName = {
    admin: "مدير النظام",
    supervisor: "مشرف النظام",
    platform_supervisor: "مشرف المنصة",
  }[profile?.role] || "مستخدم";

  return (
    <main className="students-page" dir="rtl">
      <header className="students-header">
        <a href="/dashboard" className="students-back">
          العودة إلى لوحة التحكم
        </a>

        <div className="students-header-user">
          <strong>{profile.full_name}</strong>
          <span>{roleName}</span>
        </div>
      </header>

      <div className="students-content">
        <section className="students-heading">
          <div>
            <span className="students-eyebrow">
              منظومة عَون الإدارية
            </span>

            <h1>إدارة الطلاب</h1>

            <p>
              إدارة بيانات الطلاب وأولياء أمورهم والحلقات المسجلين فيها.
            </p>
          </div>

          {!isPlatformSupervisor && (
            <a
              href="/dashboard/students/new"
              className="students-add-button"
            >
              إضافة طالب جديد
            </a>
          )}
        </section>

        {isPlatformSupervisor && (
          <div className="students-message">
            أنت تستخدم حساب مشرف المنصة. يمكنك مشاهدة بيانات الطلاب
            والبحث فيها، دون إضافة أو تعديل أو حذف أي بيانات.
          </div>
        )}

        <section className="students-summary">
          <div className="students-summary-card">
            <span>إجمالي الطلاب</span>
            <strong>{students.length}</strong>
          </div>

          <div className="students-summary-card">
            <span>الطلاب النشطون</span>
            <strong>
              {students.filter((student) => student.is_active).length}
            </strong>
          </div>

          <div className="students-summary-card">
            <span>الطلاب غير النشطين</span>
            <strong>
              {students.filter((student) => !student.is_active).length}
            </strong>
          </div>
        </section>

        <section className="students-list-section">
          <div className="students-list-heading">
            <div>
              <h2>قائمة الطلاب</h2>
              <p>
                ابحث عن الطالب أو ولي الأمر باستخدام الاسم أو اسم المستخدم.
              </p>
            </div>

            <button
              type="button"
              className="students-refresh-button"
              onClick={loadStudents}
              disabled={loading}
            >
              {loading ? "جارٍ التحديث..." : "تحديث البيانات"}
            </button>
          </div>

          <div className="students-search">
            <input
              type="search"
              value={search}
              onChange={(event) => setSearch(event.target.value)}
              placeholder="ابحث عن اسم الطالب أو ولي الأمر أو اسم المستخدم..."
              aria-label="البحث عن طالب أو ولي أمر"
            />
          </div>

          {error && (
            <div className="students-message students-error">
              <p>{error}</p>

              <button type="button" onClick={loadStudents}>
                إعادة المحاولة
              </button>
            </div>
          )}

          {loading && (
            <div className="students-message">
              جارٍ تحميل بيانات الطلاب...
            </div>
          )}

          {!loading && !error && filteredStudents.length === 0 && (
            <div className="students-empty">
              <h3>
                {students.length === 0
                  ? "لا يوجد طلاب مسجلون حتى الآن"
                  : "لم يتم العثور على نتائج"}
              </h3>

              <p>
                {students.length === 0
                  ? "لا توجد بيانات طلاب لعرضها حاليًا."
                  : "تأكد من كتابة الاسم بشكل صحيح وحاول مرة أخرى."}
              </p>
            </div>
          )}

          {!loading && !error && filteredStudents.length > 0 && (
            <div className="students-table-wrapper">
              <table className="students-table">
                <thead>
                  <tr>
                    <th>اسم الطالب</th>
                    <th>تاريخ الميلاد</th>
                    <th>ولي الأمر واسم المستخدم</th>
                    <th>الحلقة الحالية</th>
                    <th>الحالة</th>
                    <th>التفاصيل</th>
                  </tr>
                </thead>

                <tbody>
                  {filteredStudents.map((student) => (
                    <tr key={student.id}>
                      <td className="students-name-cell">
                        {getStudentName(student)}
                      </td>

                      <td>{formatDate(student.birth_date)}</td>

                      <td>
                        <div className="guardian-table-info">
                          <strong>
                            {student.guardian?.full_name || "غير محدد"}
                          </strong>

                          <span>
                            {student.guardian?.username
                              ? `اسم المستخدم: ${student.guardian.username}`
                              : "لا يوجد اسم مستخدم"}
                          </span>

                          <span
                            className={
                              student.guardian?.is_active
                                ? "guardian-account-active"
                                : "guardian-account-inactive"
                            }
                          >
                            {student.guardian?.is_active
                              ? "الحساب نشط"
                              : "الحساب مغلق"}
                          </span>
                        </div>
                      </td>

                      <td>{getCurrentClass(student)}</td>

                      <td>
                        <span
                          className={
                            student.is_active
                              ? "student-status active"
                              : "student-status inactive"
                          }
                        >
                          {student.is_active ? "نشط" : "غير نشط"}
                        </span>
                      </td>

                      <td>
                        <a
                          href={`/dashboard/educational-records?student=${encodeURIComponent(student.id)}`}
                          className="students-details-link"
                        >
                          السجل التعليمي
                        </a>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>

        <footer className="students-footer">
          منظومة عَون الإدارية - مسجد التراحم
        </footer>
      </div>
    </main>
  );
}
